# 微指令格式

32 bit

**31**: HALT	30..26 : S	**25** : CN	**23** : CP_PC	**22** : CP_MAR	**21** : CP_R	**20** : CP_IR	**19** : R_enable	**18** : R_wen	**17..15** : MUX_A	**14..12** : MUX_B

**11..10** : MUX_R_INA	**9..8** : MUX_R_INB	**7..6** : MUX_R_OUT	**5** : RD	**4** : WE	**3** : MUX_ADDR	**2..0** : code



**31..24** : Addr



 ## explanation

S, CN 为 ALU的操作码

R_enable : reg_file 使能信号

R_wen ：reg_file 写信号

MUX_A, MUX_B ：A，B选择器

MUX_R_INA ：A选择器中，reg_file 选择IR中哪一个位置的寄存器号

MUX_R_INB ：B选择器中，reg_file 选择IR中哪一个位置的寄存器号

MUX_R_OUT ：ALU的输出，reg_file 选择IR中哪一个位置的寄存器号

RD ：RAM读使能

WE：RAM写使能

MUX_ADDR：选择PC、MAR作为RAM地址线

code：下地址寻址方式

# ISA

参考MIPS 16bit指令集格式

指令均为单字长(16 bit)，通用寄存器有8个，均为16 bit

操作码为5位

有五类指令

- |  OPT   | R1(source) | R2(source) | R3(destination) |        |
  | :----: | :--------: | :--------: | :-------------: | :----: |
  | 5 bits |   3 bits   |   3 bits   |     3 bits      | 2 bits |

- |  OPT   | R1(source) |        | R3(destination) |        |
  | :----: | :--------: | :----: | :-------------: | :----: |
  | 5 bits |   3 bits   | 3 bits |     3 bits      | 2 bits |

- |  OPT   |   R1   | Immediate number |
  | :----: | :----: | :--------------: |
  | 5 bits | 3 bits |      8 bits      |

- |  OPT   | R1(source) | R2(destination) | Immediate number |
  | :----: | :--------: | :-------------: | :--------------: |
  | 5 bits |   3 bits   |     3 bits      |      5 bits      |

- |  OPT   |         |
  | :----: | :-----: |
  | 5 bits | 11 bits |

